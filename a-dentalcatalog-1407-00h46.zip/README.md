# DentalCatalog Pro 🦷

**استوديو الحالات السنّية** — منصة لأطباء الأسنان لتوثيق حالاتهم بالصور مرحلةً بمرحلة، وتحويلها إلى تصاميم «قبل/بعد» جاهزة للنشر على السوشال ميديا أو الإرسال للمريض عبر الواتساب.

**🔗 النسخة المنشورة:** https://dental-catalog-pro.netlify.app

---

## ✨ الميزات

- **توثيق الحالات بالصور**: رفع صور كل مرحلة بعنوانها (قبل / أثناء / بعد) من الموبايل مباشرة.
- **مولّد تصاميم قبل/بعد**: قوالب بمقاسات إنستغرام وتيك توك وفيسبوك مع شعار العيادة.
- **مشاركة فورية**: نشر على السوشال ميديا أو إرسال المقارنة للمريض عبر الواتساب.
- **أرشيف منظّم**: حالات مصنّفة بعنوانها ونوع العلاج، وخط زمني لجلسات كل مريض.
- **معرض عام للعيادة**: صفحة أنيقة لعرض أفضل الحالات للمرضى الجدد.
- **خصوصية كاملة**: الطبيب يقرر ما يُعرض وما يبقى خاصاً.
- **الدخول بحساب Google**: تسجيل بنقرة واحدة (الطريقة الأساسية)، مع خيار البريد الإلكتروني.
- **اشتراكات**: خطة مجانية + خطة Pro (Stripe + ZainCash).

## 🛠 التقنيات

| الطبقة | التقنية |
|---|---|
| الواجهة | Next.js 14 (App Router) + TypeScript |
| التنسيق | Tailwind CSS + خطوط Readex Pro / IBM Plex Sans Arabic |
| قاعدة البيانات والمصادقة | Supabase (Postgres + Auth + Google OAuth) |
| تخزين الصور | Cloudinary |
| الدفع | Stripe + ZainCash |
| الاستضافة | Netlify (`@netlify/plugin-nextjs`) |

## 📁 بنية المشروع

```
app/                # الصفحات (App Router)
  page.tsx          # صفحة الهبوط (سلايدر قبل/بعد تفاعلي)
  auth/             # دخول، تسجيل، callback لـ Google OAuth
  dashboard/        # لوحة الطبيب: حالات، مرضى، جلسات، معرض، إعدادات
  gallery/          # المعرض العام
  api/              # مسارات الدفع (Stripe / ZainCash)
components/
  landing/          # مكوّنات صفحة الهبوط (before-after-slider)
  auth/             # نماذج الدخول والتسجيل + AuthShell
  dashboard/        # الهيدر والتنقّل
  cases/ templates/ # معرض صور الحالة + مولّد التصاميم
lib/                # عملاء Supabase/Cloudinary + سياق المصادقة + الأنواع
styles/globals.css  # نظام التصميم الكامل
supabase/           # مخطط قاعدة البيانات
netlify.toml        # إعداد البناء والنشر
```

## 🚀 التشغيل محلياً

```bash
npm install
cp .env.example .env.local   # ثم املأ القيم
npm run dev
```

### متغيرات البيئة المطلوبة

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=
CLOUDINARY_API_KEY=
CLOUDINARY_API_SECRET=
STRIPE_SECRET_KEY=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
ZAINCASH_MERCHANT_ID=
ZAINCASH_SECRET=
NEXT_PUBLIC_APP_URL=
```

> ⚠️ لا تضع القيم الفعلية في المستودع أبداً — تُضبط في لوحة Netlify فقط.

## ☁️ النشر

النشر عبر Netlify بالأمر: `npm install && npm run build` (مضبوط في `netlify.toml`).
لتفعيل دخول Google: فعّل مزوّد Google في لوحة Supabase وأضف
`https://<site>.netlify.app/auth/callback` ضمن Redirect URLs
(الخطوات التفصيلية في ملف «اقرأني-أولاً.md»).

## 🎨 نظام التصميم

هوية مستوحاة من تطبيقات الرعاية الصحية الحديثة: تدرج أزرق–بنفسجي، بطاقات بيضاء بزوايا دائرية كبيرة، أزرار وردية للإجراءات، ودعم كامل للعربية (RTL).

---

صُنع بواسطة **دار الإبداع للحلول البرمجية** — Dar Al-Ibdaa for Software Solutions © 2026
