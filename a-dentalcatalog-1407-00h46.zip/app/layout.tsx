import { AuthProvider } from '@/lib/auth-context';
import '../styles/globals.css';
import type { Metadata } from 'next';
import { Readex_Pro, IBM_Plex_Sans_Arabic } from 'next/font/google';

const display = Readex_Pro({
  subsets: ['arabic', 'latin'],
  weight: ['500', '600', '700'],
  variable: '--font-display',
});

const body = IBM_Plex_Sans_Arabic({
  subsets: ['arabic', 'latin'],
  weight: ['400', '500', '700'],
  variable: '--font-body',
});

export const metadata: Metadata = {
  title: 'DentalCatalog Pro | استوديو حالاتك السنّية',
  description:
    'وثّق حالاتك بالصور مرحلة بمرحلة، وحوّلها إلى تصاميم قبل/بعد جاهزة للسوشال ميديا والواتساب.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={`${display.variable} ${body.variable}`}>
      <body>
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
