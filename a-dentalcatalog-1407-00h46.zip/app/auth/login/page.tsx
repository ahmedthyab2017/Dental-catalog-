import { LoginForm } from '@/components/auth/login-form';
import { AuthShell } from '@/components/auth/auth-shell';

export default function LoginPage() {
  return (
    <AuthShell tagline="استوديو حالاتك السنّية">
      <LoginForm />
    </AuthShell>
  );
}
