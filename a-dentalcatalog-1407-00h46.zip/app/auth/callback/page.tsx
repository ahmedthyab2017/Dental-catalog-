'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

export default function AuthCallbackPage() {
  const router = useRouter();
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let done = false;

    const go = async (userId: string, meta: any, email: string | undefined) => {
      if (done) return;
      done = true;
      // Ensure a clinic row exists for Google-created accounts
      const { data: clinic } = await supabase
        .from('clinics').select('id').eq('user_id', userId).maybeSingle();
      if (!clinic) {
        await supabase.from('clinics').insert([{
          user_id: userId,
          name: meta?.clinic_name || meta?.full_name || 'عيادتي',
          email: email || '',
          subscription_tier: 'free',
        }]);
      }
      router.replace('/dashboard');
    };

    supabase.auth.getSession().then(({ data }) => {
      if (data.session?.user) {
        go(data.session.user.id, data.session.user.user_metadata, data.session.user.email);
      }
    });

    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session?.user) go(session.user.id, session.user.user_metadata, session.user.email);
    });

    const t = setTimeout(() => { if (!done) setFailed(true); }, 8000);
    return () => { sub.subscription.unsubscribe(); clearTimeout(t); };
  }, [router]);

  return (
    <div className="min-h-screen bg-hero flex flex-col items-center justify-center gap-4 text-white">
      {failed ? (
        <>
          <p className="font-bold">تعذّر إكمال تسجيل الدخول</p>
          <a href="/auth/login" className="btn-gold">الرجوع لصفحة الدخول</a>
        </>
      ) : (
        <>
          <span className="w-10 h-10 rounded-full border-4 border-white border-t-transparent animate-spin" />
          <p className="text-white/80 text-sm">جاري إكمال تسجيل الدخول…</p>
        </>
      )}
    </div>
  );
}
