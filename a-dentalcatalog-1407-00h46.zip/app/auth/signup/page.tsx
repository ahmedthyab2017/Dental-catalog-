import { SignupForm } from '@/components/auth/signup-form';
import { AuthShell } from '@/components/auth/auth-shell';

export default function SignupPage() {
  return (
    <AuthShell tagline="ابدأ توثيق حالاتك اليوم">
      <SignupForm />
    </AuthShell>
  );
}
