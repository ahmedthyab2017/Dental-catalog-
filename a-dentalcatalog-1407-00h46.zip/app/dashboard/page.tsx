import { ProtectedRoute } from '@/components/protected-route';
import { DashboardHeader } from '@/components/dashboard/header';
import { DashboardNav } from '@/components/dashboard/nav';
import { DashboardStats } from '@/components/dashboard/stats';
import { PatientsList } from '@/components/dashboard/patients-list';
import { DirectoryPromo } from '@/components/dashboard/directory-promo';

export default function DashboardPage() {
  return (
    <ProtectedRoute>
      <DashboardHeader />
      <DashboardNav />
      <main className="max-w-7xl mx-auto px-4 py-6 md:py-8">
        <div className="space-y-5 md:space-y-8">
          <DashboardStats />
          <DirectoryPromo />
          <PatientsList />
        </div>
      </main>
    </ProtectedRoute>
  );
}
