import Link from 'next/link';
import { BeforeAfterSlider } from '@/components/landing/before-after-slider';

const workflow = [
  {
    title: 'صوّر ووثّق',
    desc: 'افتح الحالة، ارفع صور كل مرحلة بعنوانها — قبل، أثناء، بعد — من موبايلك مباشرة وبثوانٍ.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" /><circle cx="12" cy="13" r="4" /></svg>
    ),
  },
  {
    title: 'حوّلها إلى تصميم',
    desc: 'قوالب قبل/بعد جاهزة بمقاسات إنستغرام وتيك توك وفيسبوك، بشعار عيادتك ولمسة واحدة.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7"><rect x="3" y="3" width="18" height="18" rx="3" /><path d="M12 3v18M3 12h18" /></svg>
    ),
  },
  {
    title: 'شارك فوراً',
    desc: 'انشرها على السوشال ميديا، أو أرسل صورة قبل/بعد للمريض عبر الواتساب لتكسب ثقته وتوصيته.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7"><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4" /></svg>
    ),
  },
];

const capabilities = [
  { title: 'أرشيف حالات منظّم', desc: 'كل حالة بعنوانها ونوع علاجها ومراحلها — تلقاها بثانية بدل ما تدوّر بألبوم الموبايل.' },
  { title: 'خط زمني للمريض', desc: 'جلسات المريض وصوره مرتبة زمنياً، فتشوف تطور الحالة من أول زيارة لآخرها.' },
  { title: 'معرض عام لعيادتك', desc: 'صفحة معرض أنيقة تعرض بها أفضل حالاتك لمرضاك الجدد.' },
  { title: 'خصوصية بيدك', desc: 'أنت من يقرر أي صورة تبقى خاصة وأي حالة تُعرض — لا شيء يُنشر بدون قرارك.' },
];

export default function HomePage() {
  return (
    <main className="min-h-screen bg-pearl">
      {/* Nav */}
      <header className="sticky top-0 z-40 bg-pearl/80 backdrop-blur border-b border-line">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-xl bg-hero text-white grid place-items-center font-display font-bold text-lg">D</span>
            <span className="font-display font-bold text-lg">DentalCatalog <span className="text-teal">Pro</span></span>
          </div>
          <nav className="flex items-center gap-2">
            <Link href="/gallery" className="hidden sm:inline-block px-4 py-2 text-sm font-bold text-ink-2 hover:text-teal transition">المعرض</Link>
            <Link href="/auth/login" className="btn-ghost !px-5 !py-2">دخول</Link>
            <Link href="/auth/signup" className="btn-gold !px-5 !py-2">ابدأ مجاناً</Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden bg-hero text-white">
        <div className="absolute inset-0 opacity-[.07]" style={{ backgroundImage: 'radial-gradient(circle at 18% 18%, #ffffff 0, transparent 38%), radial-gradient(circle at 85% 78%, #3B3FD8 0, transparent 45%)' }} />
        <div className="relative max-w-6xl mx-auto px-4 py-16 md:py-24 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-xs font-bold tracking-widest uppercase text-white/70 mb-4">استوديو الحالات السنّية</p>
            <h1 className="font-display text-4xl md:text-5xl font-bold leading-[1.25] mb-5">
              حالاتك تستاهل
              <span className="text-[#FFD9E6]"> تنشاف</span>
            </h1>
            <p className="text-white/85 text-lg leading-relaxed mb-8 max-w-md">
              وثّق كل حالة بالصور مرحلة بمرحلة، وحوّلها بلمسة إلى تصميم قبل/بعد جاهز للنشر — أو أرسله للمريض عبر الواتساب.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/auth/signup" className="btn-gold">
                <svg className="w-5 h-5" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                سجّل بحساب Google
              </Link>
              <Link href="/gallery" className="btn bg-white/15 border-2 border-white/40 text-white hover:bg-white hover:text-teal">
                شاهد المعرض
              </Link>
            </div>
            <p className="mt-5 text-sm text-white/70">مجاني للبدء · بدون بطاقة ائتمان · عربي بالكامل</p>
          </div>
          <div>
            <BeforeAfterSlider />
            <p className="text-center text-white/75 text-sm mt-4">هذا ما سيراه مرضاك — جرّب السحب بنفسك</p>
          </div>
        </div>
      </section>

      {/* Workflow */}
      <section className="max-w-6xl mx-auto px-4 py-16 md:py-24">
        <p className="eyebrow text-center mb-3">من الكرسي إلى المنشور</p>
        <h2 className="section-title text-center mb-12">ثلاث خطوات، أقل من دقيقة</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {workflow.map((s, i) => (
            <div key={i} className="card hover:shadow-lift transition-shadow">
              <div className="w-14 h-14 rounded-2xl bg-teal-soft text-teal grid place-items-center mb-5">{s.icon}</div>
              <h3 className="font-display text-xl font-bold mb-2">{s.title}</h3>
              <p className="text-ink-2/80 leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Capabilities */}
      <section className="bg-white border-y border-line">
        <div className="max-w-6xl mx-auto px-4 py-16 md:py-20 grid md:grid-cols-2 gap-x-12 gap-y-10">
          {capabilities.map((c, i) => (
            <div key={i} className="flex gap-4">
              <span className="mt-1 w-2.5 h-2.5 rounded-full bg-gold shrink-0" />
              <div>
                <h3 className="font-display text-lg font-bold mb-1.5">{c.title}</h3>
                <p className="text-ink-2/75 leading-relaxed">{c.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-hero text-white">
        <div className="max-w-3xl mx-auto text-center px-4 py-16 md:py-20">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">حالتك القادمة… وثّقها صح</h2>
          <p className="text-white/85 text-lg mb-8">افتح حسابك بحساب Google خلال ثوانٍ وابدأ بأول حالة اليوم.</p>
          <Link href="/auth/signup" className="btn-gold text-base !px-8 !py-3.5">إنشاء حساب مجاني</Link>
        </div>
        <footer className="border-t border-white/15 py-6 text-center text-white/70 text-sm">
          صُنع بواسطة دار الإبداع للحلول البرمجية © {new Date().getFullYear()}
        </footer>
      </section>
    </main>
  );
}
