'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { Clinic } from '@/lib/types';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export function DashboardHeader() {
  const { user, signOut } = useAuth();
  const [clinic, setClinic] = useState<Clinic | null>(null);
  const router = useRouter();

  useEffect(() => {
    if (!user) return;
    supabase.from('clinics').select('*').eq('user_id', user.id).single()
      .then(({ data }) => setClinic(data));
  }, [user]);

  const handleSignOut = async () => {
    await signOut();
    router.push('/auth/login');
  };

  const isPro = clinic?.subscription_tier === 'pro';

  return (
    <header className="bg-hero text-white">
      <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center gap-3">
        <Link href="/dashboard" className="flex items-center gap-3 min-w-0">
          <span className="w-10 h-10 shrink-0 rounded-xl bg-white text-teal grid place-items-center font-display font-bold text-lg">
            {(clinic?.name || 'ع')[0]}
          </span>
          <span className="min-w-0">
            <span className="block font-display font-bold text-lg leading-tight truncate">{clinic?.name || 'عيادتي'}</span>
            <span className={`inline-block mt-0.5 rounded-full px-2.5 py-0.5 text-[10px] font-bold ${isPro ? 'bg-white text-teal' : 'bg-white/20 text-white/90'}`}>
              {isPro ? 'PRO' : 'الخطة المجانية'}
            </span>
          </span>
        </Link>
        <div className="flex items-center gap-2 shrink-0">
          {!isPro && (
            <Link href="/dashboard/billing" className="hidden sm:inline-flex btn-gold !px-4 !py-2 !text-xs">ترقية إلى Pro</Link>
          )}
          <button onClick={handleSignOut} className="btn border border-white/40 text-white hover:bg-white hover:text-teal !px-4 !py-2 !text-xs">
            خروج
          </button>
        </div>
      </div>
    </header>
  );
}
