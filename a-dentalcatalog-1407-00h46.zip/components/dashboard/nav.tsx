'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const items = [
  { href: '/dashboard', label: 'الرئيسية' },
  { href: '/dashboard/cases', label: 'الحالات' },
  { href: '/dashboard/patients', label: 'المرضى' },
  { href: '/dashboard/sessions', label: 'الجلسات' },
  { href: '/dashboard/gallery', label: 'المعرض' },
  { href: '/dashboard/settings', label: 'الإعدادات' },
];

export function DashboardNav() {
  const pathname = usePathname();
  return (
    <nav className="bg-white border-b border-line shadow-sm sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex gap-1.5 overflow-x-auto py-2.5 no-scrollbar">
          {items.map((item) => {
            const active = item.href === '/dashboard'
              ? pathname === '/dashboard'
              : pathname?.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-bold transition ${
                  active
                    ? 'bg-teal text-white shadow-card'
                    : 'text-ink-2/70 hover:text-teal hover:bg-teal-soft'
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
