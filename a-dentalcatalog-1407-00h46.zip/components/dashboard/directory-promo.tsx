export function DirectoryPromo() {
  return (
    <a
      href="https://www.daleel.alfalluja.com"
      target="_blank"
      rel="noopener noreferrer"
      className="block card !p-0 overflow-hidden hover:shadow-lift transition-shadow"
    >
      <div className="bg-hero text-white p-5 md:p-6 flex items-center gap-4">
        <span className="w-14 h-14 shrink-0 rounded-2xl bg-white/20 backdrop-blur grid place-items-center">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
            <path d="M21 10c0 7-9 12-9 12S3 17 3 10a9 9 0 0 1 18 0z" />
            <circle cx="12" cy="10" r="3" />
          </svg>
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-display font-bold text-base md:text-lg leading-snug">
            ضيّف عيادتك لدليل أطباء العراق والفلوجة
          </p>
          <p className="text-white/80 text-xs md:text-sm mt-1">
            ليجدك المراجعون بسهولة — سجّل مجاناً في daleel.alfalluja.com
          </p>
        </div>
        <span className="shrink-0 rounded-full bg-white text-teal font-bold text-xs px-4 py-2">
          سجّل الآن
        </span>
      </div>
    </a>
  );
}
