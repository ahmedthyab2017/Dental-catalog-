'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { Clinic } from '@/lib/types';

const icons = {
  patients: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></svg>
  ),
  sessions: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6"><path d="M8 2v4M16 2v4" /><rect x="3" y="4" width="18" height="18" rx="3" /><path d="M3 10h18M9 15h2m2 0h2" /></svg>
  ),
  revenue: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6"><circle cx="12" cy="12" r="9" /><path d="M12 7v10M15.5 9.5c-.6-1-1.9-1.5-3.5-1.5-1.8 0-3 .9-3 2.2 0 2.9 6.9 1.5 6.9 4.4 0 1.3-1.4 2.4-3.4 2.4-1.7 0-3.1-.6-3.7-1.7" /></svg>
  ),
  plan: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6"><path d="M12 2l2.9 6.3 6.9.8-5.1 4.7 1.4 6.8L12 17.3 5.9 20.6l1.4-6.8L2.2 9.1l6.9-.8z" /></svg>
  ),
};

export function DashboardStats() {
  const { user } = useAuth();
  const [clinic, setClinic] = useState<Clinic | null>(null);
  const [patientsCount, setPatientsCount] = useState(0);
  const [sessionsCount, setSessionsCount] = useState(0);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) fetchStats();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const fetchStats = async () => {
    if (!user) return;
    try {
      const { data: clinicData } = await supabase
        .from('clinics').select('*').eq('user_id', user.id).single();
      setClinic(clinicData);
      if (clinicData) {
        const { count: pCount } = await supabase
          .from('patients').select('*', { count: 'exact', head: true })
          .eq('clinic_id', clinicData.id);
        setPatientsCount(pCount || 0);
        const { data: sessionsData } = await supabase
          .from('sessions').select('amount_paid').eq('clinic_id', clinicData.id);
        setSessionsCount(sessionsData?.length || 0);
        setTotalRevenue(sessionsData?.reduce((s, x) => s + (x.amount_paid || 0), 0) || 0);
      }
    } catch (err) {
      console.error('خطأ في جلب الإحصائيات:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 animate-pulse">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-white/70 h-28 rounded-2xl border border-line" />
        ))}
      </div>
    );
  }

  const isPro = clinic?.subscription_tier === 'pro';
  const stats = [
    { label: 'المرضى', value: String(patientsCount), icon: icons.patients, iconBg: 'bg-teal-soft text-teal' },
    { label: 'الجلسات', value: String(sessionsCount), icon: icons.sessions, iconBg: 'bg-gold-soft text-gold-dark' },
    { label: 'الإيرادات', value: `$${totalRevenue.toFixed(0)}`, icon: icons.revenue, iconBg: 'bg-emerald-50 text-emerald-600' },
    { label: 'الخطة', value: isPro ? 'Pro' : 'مجانية', icon: icons.plan, iconBg: 'bg-violet-50 text-violet-500' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
      {stats.map((s, i) => (
        <div key={i} className="card !p-4 md:!p-5 flex flex-col gap-3">
          <span className={`w-11 h-11 rounded-xl grid place-items-center ${s.iconBg}`}>{s.icon}</span>
          <div>
            <div className="font-display text-2xl font-bold leading-none">{s.value}</div>
            <div className="text-ink-2/60 text-xs font-bold mt-1.5">{s.label}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
