'use client';

import { useRef, useState, useCallback } from 'react';

/**
 * Interactive before/after slider — the product, live on the landing page.
 * Uses stylized SVG panels (no patient photos needed).
 */
function SmilePanel({ variant }: { variant: 'before' | 'after' }) {
  const isAfter = variant === 'after';
  const enamel = isAfter ? '#FFFFFF' : '#E3D9BC';
  const shade = isAfter ? '#E9EDFB' : '#CBC09A';
  const bg = isAfter ? '#5B6EF5' : '#7A849E';
  return (
    <svg viewBox="0 0 600 440" className="w-full h-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <rect width="600" height="440" fill={bg} />
      <ellipse cx="300" cy="235" rx="215" ry="150" fill="#7A2E3B" />
      <ellipse cx="300" cy="235" rx="215" ry="150" fill="none" stroke="#5E1F2B" strokeWidth="10" />
      {/* upper teeth */}
      {[0, 1, 2, 3, 4, 5].map((i) => {
        const cx = 130 + i * 68;
        const arc = Math.abs(i - 2.5);
        const y = 150 + arc * arc * 6;
        const tilt = isAfter ? 0 : (i % 2 === 0 ? -6 : 7);
        return (
          <g key={'u' + i} transform={`rotate(${tilt} ${cx} ${y + 40})`}>
            <rect x={cx - 28} y={y} width="56" height="86" rx="18" fill={enamel} />
            <rect x={cx - 28} y={y + 58} width="56" height="28" rx="14" fill={shade} opacity=".55" />
          </g>
        );
      })}
      {/* lower teeth */}
      {[0, 1, 2, 3, 4, 5].map((i) => {
        const cx = 145 + i * 62;
        const arc = Math.abs(i - 2.5);
        const y = 300 - arc * arc * 5;
        const tilt = isAfter ? 0 : (i % 2 === 0 ? 8 : -5);
        return (
          <g key={'l' + i} transform={`rotate(${tilt} ${cx} ${y + 20})`}>
            <rect x={cx - 24} y={y} width="48" height="62" rx="15" fill={enamel} />
          </g>
        );
      })}
      {isAfter && (
        <g opacity=".9">
          <path d="M120 96 l7 18 18 7 -18 7 -7 18 -7 -18 -18 -7 18 -7 z" fill="#FFFFFF" />
          <path d="M480 330 l5 13 13 5 -13 5 -5 13 -5 -13 -13 -5 13 -5 z" fill="#FFFFFF" />
        </g>
      )}
    </svg>
  );
}

export function BeforeAfterSlider() {
  const [pos, setPos] = useState(50);
  const ref = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);

  const update = useCallback((clientX: number) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const pct = ((clientX - r.left) / r.width) * 100;
    setPos(Math.min(96, Math.max(4, pct)));
  }, []);

  return (
    <div
      ref={ref}
      dir="ltr"
      className="relative w-full aspect-[600/440] rounded-2xl overflow-hidden shadow-lift select-none touch-none cursor-ew-resize ring-1 ring-white/10"
      onPointerDown={(e) => { dragging.current = true; (e.target as Element).setPointerCapture?.(e.pointerId); update(e.clientX); }}
      onPointerMove={(e) => { if (dragging.current) update(e.clientX); }}
      onPointerUp={() => { dragging.current = false; }}
      role="slider"
      aria-label="مقارنة قبل وبعد"
      aria-valuenow={Math.round(pos)}
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'ArrowLeft') setPos((p) => Math.max(4, p - 4));
        if (e.key === 'ArrowRight') setPos((p) => Math.min(96, p + 4));
      }}
    >
      {/* after (full) */}
      <div className="absolute inset-0"><SmilePanel variant="after" /></div>
      {/* before (clipped) */}
      <div className="absolute inset-0" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
        <SmilePanel variant="before" />
      </div>
      {/* handle */}
      <div className="absolute inset-y-0" style={{ left: `${pos}%` }}>
        <div className="absolute inset-y-0 -translate-x-1/2 w-[3px] bg-gold" />
        <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-12 h-12 rounded-full bg-gold text-white shadow-lift grid place-items-center font-bold">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M8 7 3 12l5 5M16 7l5 5-5 5" />
          </svg>
        </div>
      </div>
      {/* labels */}
      <span className="absolute top-4 left-4 rounded-full bg-ink/60 backdrop-blur text-white text-xs font-bold px-3.5 py-1.5">قبل</span>
      <span className="absolute top-4 right-4 rounded-full bg-gold text-white text-xs font-bold px-3.5 py-1.5">بعد</span>
      <span className="absolute bottom-4 right-4 rounded-full bg-ink/50 backdrop-blur text-white/90 text-[11px] font-bold px-3 py-1.5">
        اسحب المؤشر ←→
      </span>
    </div>
  );
}
