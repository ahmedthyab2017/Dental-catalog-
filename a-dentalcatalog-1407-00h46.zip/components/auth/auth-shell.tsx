import Link from 'next/link';

export function AuthShell({ children, tagline }: { children: React.ReactNode; tagline: string }) {
  return (
    <div className="min-h-screen bg-hero relative overflow-hidden flex flex-col justify-center items-center p-4">
      <div
        className="absolute inset-0 opacity-[.08]"
        style={{ backgroundImage: 'radial-gradient(circle at 15% 15%, #ffffff 0, transparent 38%), radial-gradient(circle at 85% 85%, #3B3FD8 0, transparent 45%)' }}
      />
      <Link href="/" className="relative mb-8 flex items-center gap-3 text-white">
        <span className="w-11 h-11 rounded-xl bg-white text-teal grid place-items-center font-display font-bold text-xl">D</span>
        <span className="text-right">
          <span className="block font-display font-bold text-xl leading-tight">DentalCatalog <span className="text-[#FFD9E6]">Pro</span></span>
          <span className="block text-white/75 text-xs">{tagline}</span>
        </span>
      </Link>
      <div className="relative w-full max-w-md">{children}</div>
      <p className="relative mt-8 text-white/60 text-xs">دار الإبداع للحلول البرمجية</p>
    </div>
  );
}
