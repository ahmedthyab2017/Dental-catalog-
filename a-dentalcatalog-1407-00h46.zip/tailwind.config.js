/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // deep navy text / dark elements
        ink: { DEFAULT: '#2B3453', 2: '#3A4468', 3: '#4A5580' },
        // app background (very light blue)
        pearl: { DEFAULT: '#F4F6FB', 2: '#EBEFF9' },
        // CTA accent (pink like the kit's action buttons)
        gold: { DEFAULT: '#F5487F', dark: '#E02D68', soft: '#FDE8F0' },
        // primary blue
        teal: { DEFAULT: '#5B6EF5', dark: '#4557E0', soft: '#EEF1FE' },
        line: '#E4E9F5',
      },
      fontFamily: {
        display: ['var(--font-display)', 'sans-serif'],
        body: ['var(--font-body)', 'sans-serif'],
      },
      boxShadow: {
        card: '0 2px 6px rgba(91,110,245,.08), 0 12px 28px rgba(43,52,83,.08)',
        lift: '0 4px 10px rgba(91,110,245,.14), 0 20px 44px rgba(43,52,83,.16)',
      },
      borderRadius: { xl2: '1.5rem' },
    },
  },
};
